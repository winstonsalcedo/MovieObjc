//
//  AppDelegate.h
//  Movies2-ObJc
//
//  Created by winston salcedo on 5/31/19.
//  Copyright © 2019 Evolve Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

